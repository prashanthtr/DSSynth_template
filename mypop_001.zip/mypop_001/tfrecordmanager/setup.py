from distutils.core import setup

setup(
    name='tfrecordManager',
    version='0.1dev',
    py_modules=['tfrecords'],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.md').read()
)