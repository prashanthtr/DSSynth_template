 # paramManager

Prashanth's forked version of Lonce's paramManager with setup and init files. 

Source is https://github.com/lonce/paramManager 