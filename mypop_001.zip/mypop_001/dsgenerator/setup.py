from distutils.core import setup

setup(
    name='DSGenerator',
    version='0.1dev',
    py_modules=['generate'],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.md').read()
)