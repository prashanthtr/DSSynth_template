# Write audio data to nsjson format for training Gansynth and Nsynth
