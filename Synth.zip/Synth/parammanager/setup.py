from distutils.core import setup

setup(
    name='paramManager',
    version='0.1dev',
    py_modules=['paramManager'],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.md').read()
)